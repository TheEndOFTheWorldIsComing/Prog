﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROGT1A3
{
	class RandomGenerator

	{
		private readonly Random _random = new Random();

		// Generates a random number within a range.      
		public int RandomCallNumber(int min, int max)
		{
			return _random.Next(min, max);
		}

		// Generates a random string with a given size.    
		public string RandomString(int size, bool lowerCase = false)
		{
			var builder = new StringBuilder(size);
			char offset = lowerCase ? 'a' : 'A';
			const int lettersOffset = 26; // A...Z or a..z: length = 26  

			for (var i = 0; i < size; i++)
			{
				var @char = (char)_random.Next(offset, offset + lettersOffset);
				builder.Append(@char);
			}

			return lowerCase ? builder.ToString().ToLower() : builder.ToString();
		}

		// Generates a random callnumber  
		//three numbers . three letters
		public string RandomCallNumber()
		{
			var callNumberBuilder = new StringBuilder();
			callNumberBuilder.Append(RandomCallNumber(0, 9));
			callNumberBuilder.Append(RandomCallNumber(0, 9));
			callNumberBuilder.Append(RandomCallNumber(0, 9));
			callNumberBuilder.Append(".");
			callNumberBuilder.Append(RandomString(1));
			callNumberBuilder.Append(RandomString(1));
			callNumberBuilder.Append(RandomString(1));
			return callNumberBuilder.ToString();
		}
	}
}