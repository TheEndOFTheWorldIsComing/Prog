﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROGT1A3
{
	
	public partial class ReplacingBooks : Window
	{
		private int count = 0;
		public ReplacingBooks()
		{
			InitializeComponent();
			Score.Text = count.ToString();

			var generator = new RandomGenerator();
			for (int i = 0; i < 10; i++)
			{
				var randomCallNumber = generator.RandomCallNumber();

				listBox.Items.Add(randomCallNumber);
			}
			Check.IsEnabled = true;
		}
		private void Up_Click_1(object sender, RoutedEventArgs e)
		{
			MoveNoUp(listBox);
		}

		private void Down_Click_1(object sender, RoutedEventArgs e)
		{
			MoveNoDown(listBox);
		}

		//Move Callnumber up one space withing the list
		void MoveNoUp(ListBox callNoList)
		{
			int selectedNumber = callNoList.SelectedIndex;
			if (selectedNumber > 0)
			{
				callNoList.Items.Insert(selectedNumber - 1, callNoList.Items[selectedNumber]);
				callNoList.Items.RemoveAt(selectedNumber + 1);
				callNoList.SelectedIndex = selectedNumber - 1;
			}
		}

		//Move Callnumber down one space withing the list
		void MoveNoDown(ListBox callNoList)
		{
			int selectedNumber = callNoList.SelectedIndex;
			if (selectedNumber < callNoList.Items.Count - 1 & selectedNumber != -1)
			{
				callNoList.Items.Insert(selectedNumber + 2, callNoList.Items[selectedNumber]);
				callNoList.Items.RemoveAt(selectedNumber);
				callNoList.SelectedIndex = selectedNumber + 1;

			}
		}
		
		

		private void Check_Click_1(object sender, RoutedEventArgs e)
		{

			
			//Takes values from the list box and puts them in a list
			
			List<string> UnsortedList = listBox.Items.OfType<string>().ToList();
			
			
			// Taking the values from the first list, sorting them and putting them into another list.

			List<string> List = listBox.Items.OfType<string>().ToList();


			//splitting the strings and ordering both numerically and alphabettically 
			var SortedList = List.Select(s => new { Str = s, Split = s.Split('.') })
						.OrderBy(x => int.Parse(x.Split[0]))
						.ThenBy(x => x.Split[1])
						.Select(x => x.Str)
						.ToList();
			foreach (string s in SortedList)
				Console.WriteLine(s);

			//Comparing the UnSortedLis and the Sorted List
			//If equal the score will increase by 1 
			if (UnsortedList.SequenceEqual(SortedList))
			{

				count = count + 1;
				Score.Text = count.ToString();
				Speech.Content = "Well done! :)";
				Check.IsEnabled = false;
			}
			else
			{

				Speech.Content = "Uh oh, Try again";
			}
		}
		//Returns the user to the menu screen

		private void Menu_Click(object sender, RoutedEventArgs e)
		{
			MainWindow myForm = new MainWindow();
			this.Hide();
			myForm.ShowDialog();
			this.Close();
		}

		private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{

		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			listBox.Items.Clear();
			Check.IsEnabled = true;

			var generator = new RandomGenerator();
			for (int i = 0; i < 10; i++)
			{
				var randomCallNumber = generator.RandomCallNumber();

				listBox.Items.Add(randomCallNumber);
			}
			Check.IsEnabled = true;
			Speech.Content = "";
		}
	}
}



//________Code Attribution________\\
//  The following method was taken from 
//  Author: Peter Hansen
//  Link: https://stackoverflow.com/questions/12540457/moving-an-item-up-and-down-in-a-wpf-list-box
/*
public partial class MainWindow : Window
{
    private ObservableCollection<string> ListItems = new ObservableCollection<string>  
    { 
        "Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Item 6"
    };

    public MainWindow()
    {
        InitializeComponent();
        lbItems.ItemsSource = this.ListItems;
    }

    private void up_click(object sender, RoutedEventArgs e)
    {
        var selectedIndex = this.lbItems.SelectedIndex;

        if (selectedIndex > 0)
        {
            var itemToMoveUp = this.ListItems[selectedIndex];
            this.ListItems.RemoveAt(selectedIndex);
            this.ListItems.Insert(selectedIndex - 1, itemToMoveUp);
            this.lbItems.SelectedIndex = selectedIndex - 1;
        }
    }

    private void down_click(object sender, RoutedEventArgs e)
    {
        var selectedIndex = this.lbItems.SelectedIndex;

        if (selectedIndex + 1 < this.ListItems.Count)
        {
            var itemToMoveDown = this.ListItems[selectedIndex];
            this.ListItems.RemoveAt(selectedIndex);
            this.ListItems.Insert(selectedIndex + 1, itemToMoveDown);
            this.lbItems.SelectedIndex = selectedIndex + 1;
        }
    }
}
 */


//________End________\\



//________Code Attribution________\\
//  The following method was taken from 
//  Author: Jon Skeet
//  Link: https://stackoverflow.com/questions/12795882/quickest-way-to-compare-two-generic-lists-for-differences
/*
		var firstNotSecond = list1.Except(list2).ToList();
		var secondNotFirst = list2.Except(list1).ToList();

	return !firstNotSecond.Any() && !secondNotFirst.Any();
*/

//________End________\\